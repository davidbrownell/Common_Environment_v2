from .bycython import eval
__all__ = ('eval',)
